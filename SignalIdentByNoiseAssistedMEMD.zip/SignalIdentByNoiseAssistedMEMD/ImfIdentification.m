
%%% MEMD with added noise is performed on LFP data
%
% Please see the paper below for details:
% Meng Hu and Hualou Liang, Search for information-bearing components in
% neural data, PLoS ONE, 2014
%

%%% Meng Hu @ Drexel University, 2013

clear

load LFPdata.mat

lfp_dis=subjdis(2000:3200,:); %% use the interval of interest
lfp_nodis = subjNodis(2000:3200,:); 

%% Data is standardized by std, and save in dat_std, which will be used to restore std after EMD
dat=cat(2,lfp_dis,lfp_nodis);
dat_std=std(dat,[],1);

datnorm=dat./repmat(dat_std,size(dat,1),1);

Nn=15; 
cn=0.25; 
for n=1:Nn
datnorm=[datnorm,cn*randn(size(dat,1),1)];
end

%% MEMD with noise reference

imfx=memd_fast(datnorm,500);

%% Identification

ntr = size(dat, 2); % Total number of trials
[ch, nimf, tim]=size(imfx);
win=100;
step=10;
nwin=(tim-win)/step+1;

r=[];
for kkk=1:nwin % identification over a sliding window

w=[]; % distance between signal and added noise
intv=(kkk-1)*step+1:(kkk-1)*step+win;

for j=1:nimf
    for i=1:ntr
        for ii=ntr+1:ch
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            w(j,i,ii)=wadist(y1,y2);
        end        
    end
end
w=w(:,:,ntr+1:end);


wn=[]; %% distance between noises
for j=1:nimf
    tmp=[];
    tmp3=[];
    for i=ntr+1:ch-1
        for ii=i+1:ch
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            tmp=[tmp wadist(y1,y2)];
        end        
    end    
    wn(j,:)=tmp;
end

ww=squeeze(mean(w,3)); 
alp=0.05; %% significance level
wn=sort(wn,2);
th=wn(:,fix(size(wn,2)*(1-alp/2)));
th=repmat(th,[1 size(ww,2)]); 

r(:,:,kkk)=ww>th; %% identification

end

% save('mimf_LFP')

