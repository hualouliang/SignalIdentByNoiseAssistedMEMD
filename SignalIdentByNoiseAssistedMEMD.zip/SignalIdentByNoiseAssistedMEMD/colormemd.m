
%%% Effect of noise mismatch between the noise in the data and the added reference noise
%%% White noise and more complex noise (pink, blue), with positive / negative long-range dependence
%
% Please see the paper below for details:
% Meng Hu and Hualou Liang, Search for information-bearing components in
% neural data, PLoS ONE, 2014
%

%%% Meng Hu @ Drexel University, 2013

clear

p=[];
ix=[];

for qqq=1:100

x1=randn(1,1000); 
x2=pinknoise(1000);
x3=bluenoise(1000);

x=cat(1,x1/std(x1),x2/std(x2),x3/std(x3)); %% data consisting of three types of noises

% Decomposition
imfx=memd_fast(x,60);

for n=1:3
    for nn=1:7
        tmp=squeeze(imfx(n,nn,:));
        [p(:,n,nn,qqq),f]=pwelch(tmp,[],[],1000,1000); % spectral analysis
        [ff1,ix(:,nn,n,qqq)]=ecdf(zscore(tmp)); % CDF
    end
end

end

save colormemd

