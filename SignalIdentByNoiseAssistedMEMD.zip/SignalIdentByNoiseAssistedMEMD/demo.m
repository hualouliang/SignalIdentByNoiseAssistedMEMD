
%%% Run demo to generate the figures in the paper.
%%% The code is rather ad-hoc, specific to the paper. 
%%% Note that most simulations take some time to run, depending on your CPU

%%% In order to quickly go through proposed method, both
%%% codes and the calculated results data are provided.
%%% so you're strongly recommended to simply run with the precomputed data provided. 
% The 1st part is for simualation, and the 2nd part is from LFP analysis  
%
% Please see the paper below for details:
% Meng Hu and Hualou Liang, Search for information-bearing components in
% neural data, PLoS ONE, 2014

%%% Meng Hu @ Drexel University, 2013

%% Part 1

clear

load data4simulations.mat % Run simu1.m to generate data 

%%% Simulations, with IMFs are identified in 'r' variable (1-significant; 0 - otherwise)  

data1(1:18,1,1:1000)=x';
data1(1:18,2:7,1:1000)=imfx(:,1:6,:);
data1(1:18,8,1:1000)=sum(imfx(:,7:end,:),2);

% Figure 1
figure
set(gca,'FontWeight','bold','FontSize',14);
subplot(8,4,1);plot(x(:,1));ylabel('Raw data');title('X');ax=axis;axis([ax(1) ax(2) -5 5]);set(gca,'XTick',[])
subplot(8,4,2);plot(x(:,2));title('Y');ax=axis;axis([ax(1) ax(2) -5 5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,3);plot(x(:,3));title('Z');ax=axis;axis([ax(1) ax(2) -5 5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,4);plot(x(:,4));title('Noise Channel');ax=axis;axis([ax(1) ax(2) -1 1]);set(gca,'XTick',[])
subplot(8,4,5);plot(squeeze(imfx(1,1,:)));ylabel('C1');ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[])
subplot(8,4,6);plot(squeeze(imfx(2,1,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,7);plot(squeeze(imfx(3,1,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,8);plot(squeeze(imfx(4,1,:)));ax=axis;axis([ax(1) ax(2) -1 1]);set(gca,'XTick',[])
subplot(8,4,9);plot(squeeze(imfx(1,2,:)));ylabel('C2');ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[])
subplot(8,4,10);plot(squeeze(imfx(2,2,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,11);plot(squeeze(imfx(3,2,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,12);plot(squeeze(imfx(4,2,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[])
subplot(8,4,13);plot(squeeze(imfx(1,3,:)));ylabel('C3');ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[])
subplot(8,4,14);plot(squeeze(imfx(2,3,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,15);plot(squeeze(imfx(3,3,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,16);plot(squeeze(imfx(4,3,:)));ax=axis;axis([ax(1) ax(2) -.5 .5]);set(gca,'XTick',[])
subplot(8,4,17);plot(squeeze(imfx(1,4,:)),'r');ylabel('C4');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[])
subplot(8,4,18);plot(squeeze(imfx(2,4,:)),'r');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,19);plot(squeeze(imfx(3,4,:)),'r');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,20);plot(squeeze(imfx(4,4,:)));ax=axis;axis([ax(1) ax(2) -.2 .2]);set(gca,'XTick',[])
subplot(8,4,21);plot(squeeze(imfx(1,5,:)),'r');ylabel('C5');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[])
subplot(8,4,22);plot(squeeze(imfx(2,5,:)));ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,23);plot(squeeze(imfx(3,5,:)),'r');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,24);plot(squeeze(imfx(4,5,:)));ax=axis;axis([ax(1) ax(2) -.2 .2]);set(gca,'XTick',[])
subplot(8,4,25);plot(squeeze(imfx(1,6,:)),'r');ylabel('C6');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[])
subplot(8,4,26);plot(squeeze(imfx(2,6,:)),'r');ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,27);plot(squeeze(imfx(3,6,:)));ax=axis;axis([ax(1) ax(2) -2 2]);set(gca,'XTick',[]);set(gca,'YTick',[])
subplot(8,4,28);plot(squeeze(imfx(4,6,:)));ax=axis;axis([ax(1) ax(2) -.1 .1]);set(gca,'XTick',[])
subplot(8,4,29);plot(squeeze(data1(1,8,:)));ylabel('C7-C13');ax=axis;axis([ax(1) ax(2) -.2 .2])
subplot(8,4,30);plot(squeeze(data1(2,8,:)));ax=axis;axis([ax(1) ax(2) -.2 .2]);set(gca,'YTick',[])
subplot(8,4,31);plot(squeeze(data1(3,8,:)));ax=axis;axis([ax(1) ax(2) -.2 .2]);set(gca,'YTick',[])
subplot(8,4,32);plot(squeeze(data1(4,8,:)));ax=axis;axis([ax(1) ax(2) -.1 .1])

% print -depsc fig1.eps

%%% CDF difference in Wasserstein distance between noise and noise vs 
%%% that between signal and noise

z1=squeeze(imfx(1,2,:));
z2=squeeze(imfx(4,2,:));
z1=zscore(z1);
z2=zscore(z2);
[f1,iz1]=ecdf(z1); 
[f2,iz2]=ecdf(z2); 

% Figure 2
figure;
set(gca,'FontWeight','bold','FontSize',14);
subplot(1,2,1)

plot(f1,iz1,'linewidth',2,'Color','r');hold on;plot(f2,iz2,'linewidth',2,'linestyle','-.')
ylabel('Inverse CDF','FontSize',14)
legend('IMF 2 of X','IMF 2 of Noise Channel');
legend boxoff
ax=axis;
axis([0 1 ax(3) ax(4)])

z1=squeeze(imfx(3,5,:));
z2=squeeze(imfx(4,5,:));
z1=zscore(z1);
z2=zscore(z2);
[f1,iz1]=ecdf(z1); 
[f2,iz2]=ecdf(z2); 

subplot(1,2,2)
plot(f1,iz1,'linewidth',2,'Color','r');hold on;plot(f2,iz2,'linewidth',2,'linestyle','-.')
ylabel('Inverse CDF','FontSize',14)
legend('IMF 5 of Z','IMF 5 of Noise Channel');
legend boxoff
ax=axis;
axis([0 1 ax(3) ax(4)])

%%% Results based on Wu & Huang's method

% Figure 3
figure;
set(gca,'FontWeight','bold','FontSize',14);
subplot(1,3,1)
sig_h(squeeze(imfx(1,:,:)));axis([0 5 -8 0]);
xlabel('Ln(T)','FontSize',14);ylabel('Ln(E)','FontSize',14);title('X','FontSize',14)
text(0.6,-5.5,'C1')
text(1.2,-6.5,'C2')
text(1.8,-7.5,'C3')
text(2.6,-.8,'C4')
text(3.4,-1.8,'C5')
text(4.,-.8,'C6')

subplot(1,3,2)
sig_h(squeeze(imfx(2,:,:)));axis([0 5 -8 0]);
xlabel('Ln(T)','FontSize',14);title('Y','FontSize',14)
text(0.6,-5.8,'C1')
text(1.2,-6.2,'C2')
text(1.8,-7,'C3')
text(2.6,-.5,'C4')
text(3,-5,'C5')
text(4.,-.5,'C6')

subplot(1,3,3)
sig_h(squeeze(imfx(3,:,:)));axis([0 5 -8 0]);
xlabel('Ln(T)','FontSize',14);title('Z','FontSize',14)
text(0.6,-5.8,'C1')
text(1.2,-6.2,'C2')
text(1.8,-7,'C3')
text(2.6,-.5,'C4')
text(3,-1.3,'C5')
text(4.,-6,'C6')


%%% Performance of the method in the presence of various noise
%%% Run simu_test.m to generate data for this figure

clear

err1_all=[];
err2_all=[];

for kkk=1:9


load(['test_4snr_c',num2str(kkk)]);

alp=0.05;

N=length(w_all);

n1_all=0;
n2_all=0;
nr_all=0;
for n=1:N

    w=w_all(n).w;
    wn=wn_all(n).wn;
    
ww=squeeze(mean(w,3));
wn=sort(wn,2);
th=wn(:,fix(size(wn,2)*(1-alp/2)));
th=repmat(th,1,3);
r=th<ww;
rr=r(:);

[nimf,nch]=size(r);
nr=length(rr);

indxsig=[4 5 6 4+nimf 6+nimf 4+2*nimf 5+2*nimf];
indxnonsig=ones(1,nr);
indxnonsig(indxsig)=0;
indxnonsig=find(indxnonsig==1);

n1=sum(rr(indxsig));
n2=sum(rr(indxnonsig));


n1_all=n1_all+n1;
n2_all=n2_all+n2;
nr_all=nr_all+nr;

end

err1=1-n1_all/(N*7);
err2=n2_all/(nr_all-N*7);

err1_all(kkk)=err1;
err2_all(kkk)=err2;

end

% Figure 4
figure;
set(gca,'FontWeight','bold','FontSize',14);
plot(c,err1_all,'linewidth',2,'Color','r');hold on;plot(c,err2_all,'linewidth',2,'linestyle','--')
axis([0.1 2 0 1])
set(gca,'XTickLabel',{'13.9','7.9 ','4.4 ','1.9 ',' 0  ','-1.6','-2.9','-4.1','-5.1','-6.0'})

xlabel('SNR (dB)','FontSize', 14);
ylabel('Error Rate','FontSize', 14);
legend('Type I Error','Type II Error');
legend boxoff

%%% Effect of noise mismatch between the noise in the data and the added reference noise
%%% White noise and more complex noise (pink, blue), with positive / negative long-range dependence
%%% Run coloremd.m to produce 'colormend.mat'

clear

load colormemd

p=squeeze(mean(p,4));
ix=squeeze(mean(ix,4));

% Figure 5
figure;
set(gca,'FontWeight','bold','FontSize',14);
subplot(3,2,1)
plot(f,squeeze(p(:,1,:)))
ax=axis;
axis([0 500 ax(3) ax(4)]);
text(4,2.7e-3,'7');text(12,2.7e-3,'6');text(26,2.7e-3,'5');
text(50,2.7e-3,'4');text(100,2.7e-3,'3');text(200,2.7e-3,'2');
text(400,2.7e-3,'1')
text(300,0.5e-3,'White noise')
set(gca,'YTick',[])

subplot(3,2,3)
plot(f,squeeze(p(:,2,:)))
ax=axis;
axis([0 500 ax(3) ax(4)]);
text(4,0.009,'7');text(12,0.009,'6');text(26,0.009,'5');
text(50,0.009,'4');text(100,0.009,'3');text(200,0.009,'2');
text(400,0.009,'1')
text(50,0.005,'Positive long-range dependence noise')
set(gca,'YTick',[])

subplot(3,2,5)
plot(f,squeeze(p(:,3,:)))
xlabel('Frequency (Hz)','FontSize',14);
ax=axis;
axis([0 500 ax(3) ax(4)]);
text(4,0.005,'7');text(12,0.005,'6');text(26,0.005,'5');
text(50,0.005,'4');text(100,0.005,'3');text(200,0.005,'2');
text(400,0.005,'1')
text(50,0.003,'Positive long-range dependence noise')
set(gca,'YTick',[])

for n=3
%     figure
subplot(3,2,[2 4 6])
    plot(ff1,squeeze(ix(:,n,:)));legend('White','Pink','Blue');legend boxoff; 
    ylabel('Inverse CDF','FontSize',14);
end

%% Part 2

%%%%% Main results from local field potential data analysis
%%%  Run ImfIdentification.m to generate precomputed results  
%%%  

Fig6Code; % To reproduce Fig.6 in the paper

% To reproduce the Figs.7-8
clear

load mimf_LFP.mat

t=linspace(-200,1000,1201);

rr=sum(r,3);
indr=double(rr>0);
indr1=indr(:,1:size(lfp_dis,2))';
indr2=indr(:,size(lfp_dis,2)+1:end)';
imfx=imfx(1:size(lfp_dis,2)+size(lfp_nodis,2),:,:);
imfstd=repmat(dat_std',[1,size(imfx,2),size(imfx,3)]);
imfx=imfx.*imfstd; % std restored

imfx1=imfx(1:size(lfp_dis,2),:,:);
imfx2=imfx(size(lfp_dis,2)+1:size(lfp_dis,2)+size(lfp_nodis,2),:,:);

pow1_all=[]; % power of IMFs in conditon 1
for n=1:size(indr1,2)
    powtmp=[];
    k=0;
    for nn=1:size(indr1,1)
        if indr1(nn,n)==1
            k=k+1;
            tmp=squeeze(imfx1(nn,n,:));
            powtmp(:,k)=(abs(hilbert(tmp)));
        end
    end
    pow1_all(n).pow=powtmp;
end

pow2_all=[]; % power of IMFs in conditon 2
for n=1:size(indr2,2)
    powtmp=[];
    k=0;
    for nn=1:size(indr2,1)
        if indr2(nn,n)==1
            k=k+1;
            tmp=squeeze(imfx2(nn,n,:));
            powtmp(:,k)=(abs(hilbert(tmp)));
        end
    end
    pow2_all(n).pow=powtmp;
end
intv=500:1150;
m1=[]; %% mean of power in condition 1
m2=[]; %% mean of power in condition 2
err1=[];  %% SEM of power in condition 1
err2=[];  %% SEM of power in condition 2
for n=1:length(pow1_all)
    try
    tmp1=pow1_all(n).pow;
    tmp2=pow2_all(n).pow;
    tmp1=mean(tmp1(intv,:),1);
    tmp2=mean(tmp2(intv,:),1);    
    m1(n)=mean(tmp1);
    m2(n)=mean(tmp2);
    err1(n)=std(tmp1)/sqrt(length(tmp1));
    err2(n)=std(tmp2)/sqrt(length(tmp2));
    end
      
end

% Among identified IMFs, only 5:7 components seem visibility-relevant when compared between two conditions  
% Signal identification is improved by using moving window to capture
% transient signals and to accout for nonstatiuonary data

m1=m1(5:7); 
m2=m2(5:7);
err1=err1(5:7);
err2=err2(5:7);

% Left panel of Figure 7
figure
set(gca,'FontWeight','bold','FontSize',14);
subplot(1,2,1)
errorbar([5 6 7],m1,3*err1,'--*');
hold on
errorbar([5 6 7],m2,3*err2,'-ro');
xlabel('Index of IMF','FontSize',14);
ylabel('IMF Power','FontSize',14);
legend('Invisible','Visible');legend boxoff
axis([4.8 7.2 5 20])
set(gca,'XTickLabel',{'5',' ','6',' ','7'})

intv=500:1150;
for n=6
    try
    tmp1=pow1_all(n).pow;
    tmp2=pow2_all(n).pow;
    zi1=mean(tmp1(intv,:),1);
    zi2=mean(tmp2(intv,:),1);    

    end
      
end

% Perform decoding to quantify the ability of proposed method, compare to Wu & Huang method 
% Run 10 times on data split to get errorbar, thouth leave-one-out CV is
% prefered for small sample size

zi=[];zilab=[];
zi=[zi1,zi2];
zilab=[zeros(size(zi1)),ones(size(zi2))];

win=10; % About 75/25 split for small sample size
step=3; %  'win' and 'step' should be changed for the different cross-validations. 
        % Note that for the different number of IMFs, win and step may need 
        % be changed to group samples for classification.

method='rbf';
rate1=[];
for nt=1:10 
    
    indtest=[((nt-1)*step+1):((nt-1)*step+win)];
    % indtest = randsample(numel(zilab),round(numel(zilab)/4)); 
                % use this one to make sure the index within the range of
                % zilab if win & step are not changed
    tmp=zeros(size(zi));
    tmp(indtest)=1;
    indtrain=find(tmp==0);
    
    SVMStruct1 = svmtrain(zi(indtrain)',zilab(indtrain)','kernel_function',method);
    out1 = svmclassify(SVMStruct1,zi(indtest)');
    
    anw=zilab(indtest)';
    
    rate1(nt)=1-sum(abs(out1-anw))/win;


end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% check if IMF 6 in proposed method does better than Wu & Huang's method 

load mimf_LFP.mat

rr=sum(r,3);
indr=double(rr>0);
indr=ones(size(rr));
indr1=indr(:,1:size(lfp_dis,2))';
indr2=indr(:,size(lfp_dis,2)+1:end)';
imfx=imfx(1:size(lfp_dis,2)+size(lfp_nodis,2),:,:);
imfstd=repmat(dat_std',[1,size(imfx,2),size(imfx,3)]);
imfx=imfx.*imfstd; % std restored

imfx1=imfx(1:size(lfp_dis,2),:,:);
imfx2=imfx(size(lfp_dis,2)+1:size(lfp_dis,2)+size(lfp_nodis,2),:,:);

pow1_all=[]; % Power in condition 1
for n=1:size(indr1,2)
    powtmp=[];
    k=0;
    for nn=1:size(indr1,1)
        if indr1(nn,n)==1
            k=k+1;
            tmp=squeeze(imfx1(nn,n,:));
            powtmp(:,k)=abs(hilbert(tmp));
        end
    end
    pow1_all(n).pow=powtmp;
end

pow2_all=[]; % Power in condition 2
for n=1:size(indr2,2)
    powtmp=[];
    k=0;
    for nn=1:size(indr2,1)
        if indr2(nn,n)==1
            k=k+1;
            tmp=squeeze(imfx2(nn,n,:));
            powtmp(:,k)=abs(hilbert(tmp));
        end
    end
    pow2_all(n).pow=powtmp;
end
intv=500:1150;
m1=[];
m2=[];
err1=[];
err2=[];
for n=1:length(pow1_all)
    try
    tmp1=pow1_all(n).pow;
    tmp2=pow2_all(n).pow;
    tmp1=mean(tmp1(intv,:),1);
    tmp2=mean(tmp2(intv,:),1);
    m1(n)=mean(tmp1); % mean of power in condition 1
    m2(n)=mean(tmp2); % mean of power in condition 2
    err1(n)=std(tmp1)/sqrt(length(tmp1)); % SEM of power in condition 1
    err2(n)=std(tmp2)/sqrt(length(tmp2)); % SEM of power in condition 2
    end
      
end

% Pick corresponding IMFs above for comparison
m1=m1(5:7);
m2=m2(5:7);
err1=err1(5:7);
err2=err2(5:7);

% Right panel of Figure 7
subplot(1,2,2)
errorbar([5 6 7],m1,3*err1,'--*');
hold on
errorbar([5 6 7],m2,3*err2,'-ro');
xlabel('Index of IMF','FontSize',14);
ylabel('IMF Power','FontSize',14);
legend('Invisible','Visible');legend boxoff
axis([4.8 7.2 5 20])
set(gca,'XTickLabel',{'5',' ','6',' ','7'})

% export_fig fig7 -tiff -m3 -transparent -nocrop

intv=500:1150;
for n=6
    try
    tmp1=pow1_all(n).pow;
    tmp2=pow2_all(n).pow;
    zr1=mean(tmp1(intv,:),1);
    zr2=mean(tmp2(intv,:),1);

    end
      
end

method='rbf';

zr=[];zrlab=[];
zr=[zr1,zr2];
zrlab=[zeros(size(zr1)),ones(size(zr2))];

win=14; % about 75/25 split
step=5;

rate2=[];
for nt=1:10
    
    indtest=[((nt-1)*step+1):((nt-1)*step+win)];
    % indtest = randsample(numel(zrlab),round(numel(zrlab)/4));
    
    tmp=zeros(size(zr));
    tmp(indtest)=1;
    indtrain=find(tmp==0);
    
    SVMStruct1 = svmtrain(zr(indtrain)',zrlab(indtrain)','kernel_function',method);
    out2 = svmclassify(SVMStruct1,zr(indtest)');
    
    anw=zrlab(indtest)';
    
    rate2(nt)=1-sum(abs(out2-anw))/win;


end

% Figure 8
figure
set(gca,'FontWeight','bold','FontSize',14);
bar([mean(rate1) mean(rate2)],0.25,'black');axis([0.6 2.4 0.5 0.85]) 
ylabel('Decoding Accuracy','FontSize',14);
hold on
plot([1 1],[mean(rate1) mean(rate1)+std(rate1)/sqrt(10)],'color','black')
plot([0.95 1.05],[mean(rate1)+std(rate1)/sqrt(10) mean(rate1)+std(rate1)/sqrt(10)],'color','black')

plot([2 2],[mean(rate2) mean(rate2)+std(rate2)/sqrt(10)],'color','black')
plot([1.95 2.05],[mean(rate2)+std(rate2)/sqrt(10) mean(rate2)+std(rate2)/sqrt(10)],'color','black')
set(gca,'XTickLabel',{'Proposed method','Method in [12] '},'FontSize',14)


% export_fig fig8 -tiff -m3 -transparent -nocrop


