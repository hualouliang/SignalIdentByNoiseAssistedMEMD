function sig_h(imf)

%%% sig_h(imf), Implement Wu & Huang's method

%%% Meng Hu @ Drexel University, 2013

l=length(imf);

t1=0:0.01:10;

tval=2.326;

y1=-t1+tval*1/sqrt(l)*sqrt(2)*exp(t1/2);
y2=-t1-tval*1/sqrt(l)*sqrt(2)*exp(t1/2);

% figure;
plot(t1,y1,'linewidth',2,'LineStyle',':');
hold on
plot(t1,y2,'linewidth',2,'LineStyle',':');

En=mean(imf.^2,2);

for n=1:size(imf,1)-1
tmp=imf(n,:);
[indmin, indmax, indzer] = extr(tmp);
plot(log(l/(max(length(indmin),length(indmax)))),log(En(n)),'*r');
end

end


