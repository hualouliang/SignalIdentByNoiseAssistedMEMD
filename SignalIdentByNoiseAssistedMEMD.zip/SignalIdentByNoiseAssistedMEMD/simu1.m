
% % Simulations of signal identification via Noise-aided MEMD. 
% %     Identify the informatic components in the synthetic data [x1,x2,x3]
% % Steps: 
% %     1.Several noises are added as the additonal channels to synthetic data
% %     2.MEMD is applied to composite data
% %     3.W-distance is applied to identify the informatic IMFs


%%% Simualation of several sine waves with different freqs plus noise
%%% then MEMD is performed, finally with W-distance for signal identification
%
% Please see the paper below for details:
% Meng Hu and Hualou Liang, Search for information-bearing components in
% neural data, PLoS ONE, 2014
%

%%% Meng Hu @ Drexel University, 2013

clear

%% Data generation
t=0.001:0.001:1;
a1=sin(2*pi*12*t);
a2=sin(2*pi*26*t);
a3=sin(2*pi*50*t);
c=0.1;
x1=a2+a3+c*randn(size(a1))+a1;
x2=a3+c*randn(size(a1))+a1;
x3=a2+c*randn(size(a1))+a3;

%% Add noise channels
x=[x1/std(x1);x2/std(x2);x3/std(x3)];
Nn=15; % number of noise channels
cn=0.25; % amount of noise added
for n=1:Nn
    x=[x;cn*randn(size(a1))];
end
x=x';

%% MEMD in work
imfx=memd_fast(x,150);

%% Compute the similarity using Wasserstein distance 
[ch, nimf, tim]=size(imfx);
w=[]; % Wasserstein distance between signal and noise
intv=101:900; % remove end effect of MEMD
for j=1:nimf
    for i=1:3
        for ii=4:ch 
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            w(j,i,ii)=wadist(y1,y2);        
        end
    end
end
w=w(:,:,4:end);

wn=[];% Wasserstein distance between noises
for j=1:nimf
    tmp=[];
    for i=4:ch-1
        for ii=i+1:ch
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            tmp=[tmp wadist(y1,y2)];        
        end
    end
    wn(j,:)=tmp;  
end

%% Identification
alp=0.05; %% significance level, with alpha = 0.05
    
ww=squeeze(mean(w,3)); %% distance between signal and noise
wn=sort(wn,2);
th=wn(:,fix(size(wn,2)*(1-alp/2))); %% threshold for test
th=repmat(th,1,3);
r=th<ww; % IMFs are identified in 'r' variable (1-significant; 0 - otherwise)  

% save('data4simulations');    


