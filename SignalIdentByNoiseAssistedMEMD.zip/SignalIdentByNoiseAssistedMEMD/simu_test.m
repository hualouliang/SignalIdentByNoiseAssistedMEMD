%%% Simulation to test performance of the method in the presence of various
%%% noise
%
% Please see the paper below for details:
% Meng Hu and Hualou Liang, Search for information-bearing components in
% neural data, PLoS ONE, 2014
%

%%% Meng Hu @ Drexel University, 2013

clear

t=0.001:0.001:1;

a1=sin(2*pi*12*t);
a2=sin(2*pi*26*t);
a3=sin(2*pi*50*t);

c=[0.1 0.3 0.5 0.8 1 1.2 1.5 1.7 2]; %% different noise levels

for p=1:length(c)
    
    w_all=[];
    wn_all=[];
    
    for pp=1:100

x1=a2+a3+a1; x1=x1./std(x1);
x1=x1+c(p)*randn(size(a1));

x2=a3+a1; x2=x2./std(x2);
x2=x2+c(p)*randn(size(a1));

x3=a2+a3; x3=x3./std(x3);
x3=x3+c(p)*randn(size(a1));

x=[x1/std(x1);x2/std(x2);x3/std(x3)]; % generated data 

Nn=15; 
cn=0.25; 
for n=1:Nn
    x=[x;cn*randn(size(a1))];
end
x=x'; 

% MEMD in work
imfx=memd_fast(x,150);

% Signal identification based on Wasserstein distance 
[ch, nimf, tim]=size(imfx);

% distance between signal and added noise
w=[];
intv=101:900;
for j=1:nimf
    for i=1:3
        for ii=4:ch
  
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            w(j,i,ii)=wadist(y1,y2);
        
        end
    end
end
w=w(:,:,4:end);

% distance between added noises
wn=[];
for j=1:nimf
    tmp=[];
    tmp3=[];
    for i=4:ch-1
        for ii=i+1:ch
  
            y1=squeeze(imfx(i,j,intv));
            y2=squeeze(imfx(ii,j,intv));
            tmp=[tmp wadist(y1,y2)];
        
        end
    end
    wn(j,:)=tmp;
    
end


w_all(pp).w=w;
wn_all(pp).wn=wn;

    end
    
save(['test_4snr_c',num2str(p)]);    

end

